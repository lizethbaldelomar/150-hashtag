from Tkinter import *

import parser

from PIL import Image, ImageTk

import tkMessageBox

import tkFileDialog

import tkSimpleDialog

import os



class GUI:

	def __init__(self, parent):

		self.filename="" #filename of the file - if saved

		self.state = 1

		self.parent = parent

		self.parent.title("Hash Code")

		self.parent.minsize(1200,600)

		self.parent.grid_rowconfigure(0, weight=1)

		self.parent.grid_columnconfigure(0, weight=1)

			

		self.canvas=Canvas(self.parent)

		self.canvas.grid(row=0, column=0, sticky="nswe")

		#yScroll=Scrollbar(self.parent, orient=VERTICAL, command=self.canvas.yview)

		#yScroll.grid(row=0, column=1, sticky='ns') #scrollbar of the whole window

		#xScroll=Scrollbar(self.parent, orient=HORIZONTAL, command=self.canvas.xview)

		#xScroll.grid(row=1, column=0, sticky='we')

		#self.canvas.configure(yscrollcommand=yScroll.set, xscrollcommand=xScroll.set)

		#self.canvas.configure(scrollregion=(0,0,1200,800))

		#frame of buttons e.g. new, open, etc

		self.frame2 = Frame(self.canvas, relief=FLAT,width=800,height=70, bg="black")

		self.canvas.create_window(500, 567, window=self.frame2, anchor=W) 

		#frame - text widget of codes

		self.codeframe = Frame(self.canvas, relief=FLAT,width=800,height=600)

		self.codeframe.grid_propagate(False)

		self.codeframe.grid_rowconfigure(0, weight=1)

		self.codeframe.grid_columnconfigure(0, weight=1)

		self.canvas.create_window(30,300, window=self.codeframe, anchor=W) 

		#frame - text widget for user input



		#frame - line numbers

		self.frameforlines=Frame(self.canvas, relief=FLAT,width=100,height=600) 

		self.canvas.create_window(0,300, window=self.frameforlines, anchor=W)

		#frame - output of program

		self.outputframe=Frame(self.canvas, relief=SUNKEN,width=400,height=600)

		self.canvas.create_window(1090,266,window=self.outputframe) 


		#scrollbar of outputframe

		scrollbar=Scrollbar(self.outputframe)

		scrollbar.pack(side=RIGHT, fill=Y)

		#output is a listbox

		self.listbox=Text(self.outputframe, width=71,height=35,yscrollcommand=scrollbar.set)

		self.listbox.pack()



		self.listbox.config(yscrollcommand=scrollbar.set)

		scrollbar.config(command=self.listbox.yview)

		#label - input

		#self.input = Label(self.canvas, text="Input",width=30,height=1, bg="Gray")

		#self.canvas.create_window(840,735,window=self.input) 

		#compile button

		self.photo4 = ImageTk.PhotoImage(Image.open("compile.jpg").resize((129,62), Image.ANTIALIAS)) 

		self.compile = Button(self.frame2, image = self.photo4, bg = "black", command = self.runParser)

		self.compile.place(relx=0.56,rely=0.001)

		#run button

		self.photo5 = ImageTk.PhotoImage(Image.open("run.jpg").resize((129,62), Image.ANTIALIAS)) 

		self.run = Button(self.frame2, image = self.photo5, bg = "black", command = self.runProg)

		self.run.place(relx=0.72,rely=0.001)

		#open button

		self.photo2 = ImageTk.PhotoImage(Image.open("open.jpg").resize((129,62), Image.ANTIALIAS)) 

		self.open1 = Button(self.frame2, image = self.photo2, bg = "black", command=self.openfile)

		self.open1.place(relx=0.40,rely=0.001)


		#scrollbar - code and line number

		scrollCode=Scrollbar(self.codeframe, command=self.scrollforwidgets)

		scrollCode.grid(row=0, column=1, sticky='ns')

		

		#line number

		self.linenumber = Listbox(self.frameforlines, width=4,height=37, bg="lightgray", yscrollcommand=scrollCode.set)

		self.linenumber.pack(side='left') 

		#input part for the code dito nagiinput

		self.code = Text(self.codeframe, relief=SUNKEN, bg = "gray") 

		self.code.config(width=530, height=600, padx=4, undo=True, wrap=NONE, yscrollcommand=scrollCode.set)

		self.code.grid(row=0, column=0, sticky='nsew', padx=2, pady=2)



		scrollCodeX=Scrollbar(self.codeframe, orient=HORIZONTAL, command=self.code.xview)

		scrollCodeX.grid(row=1, column=0, sticky='we')

		self.code.config(xscrollcommand=scrollCodeX.set)



		for i in range(2000):

			self.linenumber.insert(END, str(i+1))



		parser.hashGUI = self

		self.initHelloWorld()	

		

	def initHelloWorld(self):


		path = os.path.realpath("hash.txt")

		#print path

		self.filename = path

		f = open(self.filename, "r")

		text = f.read()

		self.putCode(text)

		#self.runParser2()

		#self.runProg()

		

	def scrollforwidgets(self, *args):

		self.code.yview(*args)

		self.linenumber.yview(*args)

			
	def currentfilename(self, name):

		self.filename=name


	def openfile(self):


		filenames=tkFileDialog.askopenfilename(filetypes=[('Hash Code Files', '.hash')])

		if filenames[-5:] == ".hash":

			self.filename=filenames

			f=open(filenames, "r")

			text=f.read()

			self.putCode(text)

	

	def putCode(self, text):

		# putcode to output text widget

		self.code.delete(1.0, END)

		self.code.insert(INSERT, text)


	def runParser2(self):

		# runs the parser and changes calls self.changeBtnState()

		self.listbox.delete(1.0, END)

		self.state = parser.start(self.filename)

		self.changeBtnState()


	def runParser(self):
		temp = self.filename

		self.filename=tkFileDialog.asksaveasfilename(filetypes=[('Hash Code Files', '.hash')])

		if not self.filename=="":

			text=self.code.get(1.0, END)

			text = text[0:len(text) - 1]

			filesave=open(self.filename, "w")

			filesave.write(text)

			filesave.close()

		if self.filename == "":

			self.filename = temp

		# runs the parser and changes calls self.changeBtnState()

		self.listbox.delete(1.0, END)

		self.state = parser.start(self.filename)

		self.changeBtnState()



			

		

	def changeBtnState(self):

		# changeBtnState() changes the state of the button to disabled if there are errors

		if self.state == 1:

			self.run.config(state = NORMAL)

		else:

			self.run.config(state = DISABLED)

			


	def runProg(self):

		# imports prog2 and assigns hpGui as a global variable in that module. Reloads the module in case changes are made to the program

		import translated

		translated.hashGUI = self

		translated = reload(translated)

		# output is inserted to the output text widget

		z = open("output.txt", "r")

		text = z.read()

		self.listbox.delete(1.0, END)

		self.listbox.insert(INSERT, text)

		z.close()

		

	def getIntInput(self):

		# called from inside the prog to ask for an integer input

		input = tkSimpleDialog.askinteger("Integer input", "Input an integer")

		return input

		

	def getStrInput(self):	

		# called from inside the prog to ask for a string input

		input = tkSimpleDialog.askstring("String input", "Input a string")

		return input

		

root = Tk()

#root.geometry("{0}x{1}+0+0".format(root.winfo_screenwidth(), root.winfo_screenheight()))

hashGUI = GUI(root)			

root.mainloop()



