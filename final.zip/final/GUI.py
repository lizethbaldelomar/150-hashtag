from Tkinter import *

import parser

from PIL import Image, ImageTk

import tkMessageBox

import tkFileDialog

import tkSimpleDialog

import os



class GUI:

	def __init__(self, parent):

		self.filename=""

		self.state = 1

		self.parent = parent

		self.parent.title("Hash Code")

		self.parent.minsize(1200,600)

		self.parent.grid_rowconfigure(0, weight=1)

		self.parent.grid_columnconfigure(0, weight=1)
			

		self.canvas=Canvas(self.parent)

		self.canvas.grid(row=0, column=0, sticky="nswe")


		self.frame2 = Frame(self.canvas, relief=FLAT,width=800,height=70, bg="black")

		self.canvas.create_window(500, 567, window=self.frame2, anchor=W) 


		self.codeframe = Frame(self.canvas, relief=FLAT,width=800,height=600)

		self.codeframe.grid_propagate(False)

		self.codeframe.grid_rowconfigure(0, weight=1)

		self.codeframe.grid_columnconfigure(0, weight=1)

		self.canvas.create_window(30,300, window=self.codeframe, anchor=W) 


		self.frameforlines=Frame(self.canvas, relief=FLAT,width=100,height=600) 

		self.canvas.create_window(0,300, window=self.frameforlines, anchor=W)


		self.outputframe=Frame(self.canvas, relief=SUNKEN,width=400,height=600)

		self.canvas.create_window(1090,266,window=self.outputframe) 


		scrollbar=Scrollbar(self.outputframe)

		scrollbar.pack(side=RIGHT, fill=Y)


		self.listbox=Text(self.outputframe, width=71,height=35,yscrollcommand=scrollbar.set)

		self.listbox.pack()



		self.listbox.config(yscrollcommand=scrollbar.set)

		scrollbar.config(command=self.listbox.yview)


		self.photo4 = ImageTk.PhotoImage(Image.open("compile.jpg").resize((129,62), Image.ANTIALIAS)) 

		self.compile = Button(self.frame2, image = self.photo4, bg = "black", command = self.runParser)

		self.compile.place(relx=0.56,rely=0.001)



		self.photo5 = ImageTk.PhotoImage(Image.open("run.jpg").resize((129,62), Image.ANTIALIAS)) 

		self.run = Button(self.frame2, image = self.photo5, bg = "black", command = self.runProg)

		self.run.place(relx=0.72,rely=0.001)


		self.photo2 = ImageTk.PhotoImage(Image.open("open.jpg").resize((129,62), Image.ANTIALIAS)) 

		self.open1 = Button(self.frame2, image = self.photo2, bg = "black", command=self.openfile)

		self.open1.place(relx=0.40,rely=0.001)


		scrollCode=Scrollbar(self.codeframe, command=self.scrollforwidgets)

		scrollCode.grid(row=0, column=1, sticky='ns')


		self.linenumber = Listbox(self.frameforlines, width=4,height=37, bg="lightgray", yscrollcommand=scrollCode.set)

		self.linenumber.pack(side='left') 



		self.code = Text(self.codeframe, relief=SUNKEN, bg = "gray") 

		self.code.config(width=530, height=600, padx=4, undo=True, wrap=NONE, yscrollcommand=scrollCode.set)

		self.code.grid(row=0, column=0, sticky='nsew', padx=2, pady=2)



		scrollCodeX=Scrollbar(self.codeframe, orient=HORIZONTAL, command=self.code.xview)

		scrollCodeX.grid(row=1, column=0, sticky='we')

		self.code.config(xscrollcommand=scrollCodeX.set)



		for i in range(2000):

			self.linenumber.insert(END, str(i+1))



		parser.hashGUI = self

		self.initHelloWorld()	

		

	def initHelloWorld(self):


		path = os.path.realpath("hash.txt")

		self.filename = path

		f = open(self.filename, "r")

		text = f.read()

		self.putCode(text)

		

	def scrollforwidgets(self, *args):

		self.code.yview(*args)

		self.linenumber.yview(*args)

			
	def currentfilename(self, name):

		self.filename=name


	def openfile(self):


		filenames=tkFileDialog.askopenfilename(filetypes=[('Hash Code Files', '.hash')])

		if filenames[-5:] == ".hash":

			self.filename=filenames

			f=open(filenames, "r")

			text=f.read()

			self.putCode(text)

	

	def putCode(self, text):

		self.code.delete(1.0, END)

		self.code.insert(INSERT, text)


	def runParser2(self):

		self.listbox.delete(1.0, END)

		self.state = parser.start(self.filename)

		self.changeBtnState()


	def runParser(self):
		temp = self.filename

		self.filename=tkFileDialog.asksaveasfilename(filetypes=[('Hash Code Files', '.hash')])

		if not self.filename=="":

			text=self.code.get(1.0, END)

			text = text[0:len(text) - 1]

			filesave=open(self.filename, "w")

			filesave.write(text)

			filesave.close()

		if self.filename == "":

			self.filename = temp


		self.listbox.delete(1.0, END)

		self.state = parser.start(self.filename)

		self.changeBtnState()



			

		

	def changeBtnState(self):


		if self.state == 1:

			self.run.config(state = NORMAL)

		else:

			self.run.config(state = DISABLED)

			


	def runProg(self):

		import translated

		translated.hashGUI = self

		translated = reload(translated)

		z = open("output.txt", "r")

		text = z.read()

		self.listbox.delete(1.0, END)

		self.listbox.insert(INSERT, text)

		z.close()

		

	def getIntInput(self):

		input = tkSimpleDialog.askinteger("Integer input", "Input an integer")

		return input

		

	def getStrInput(self):

		input = tkSimpleDialog.askstring("String input", "Input a string")

		return input

		

root = Tk()

hashGUI = GUI(root)			

root.mainloop()



