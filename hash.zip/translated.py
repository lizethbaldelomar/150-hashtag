import sys
import time
import tkSimpleDialog
sys.stdout=open('output.txt', 'w')

def main():
	print "Enter the lowest year "
	minyear = tkSimpleDialog.askinteger("Integer input", "Input an integer")
	sys.stdout.flush()
	print "Enter the highest year "
	maxyear = tkSimpleDialog.askinteger("Integer input", "Input an integer")
	sys.stdout.flush()
	print "Leap years in given range are "
	for year in range (minyear, maxyear+1):
		if (year%4==0):
			if (year%100!=0):
				print year
			elif (year==0):
				print year

main()
sys.stdin=sys.__stdin__
sys.stdout=sys.__stdout__